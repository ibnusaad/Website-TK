<link rel="stylesheet" type="text/css" href="plugin/validity/jquery.validity.css">
<script type="text/javascript" src="plugin/validity/jquery.validity.min.js"></script>
<script type="text/javascript">
	$(function(){
		$('#formkontak').validity(function(){
			$('#nama')
					.require(' Nama tidak boleh kosong!');
			$('#email')
					.require(' Email tidak boleh kosong!')
					.match('email',' Email tidak valid!');
			$('#pesan')
					.require(' Pesan tidak boleh kosong');			
		});
	});
</script>
<?php
	if(!defined("INDEX")) die("---");	
?>

<ul class="breadcrumb">
	<li>Home</li>
	<li class="active">Kontak kami</li>
</ul>

        
                    <div class="get-right">
                        <form>
                                <ul>
                                    <li class="name">
                                        <a href="#" class="icon user"> </a>
                                        <input type="text" placeholder="Your name" required="">
                                        <div class="clear"> </div>
                                    </li> 
                                    <li class="email_1">
                                        <a href="#" class="icon mail"> </a>
                                        <input type="email" placeholder="yourname@email.com" required="">
                                        <div class="clear"> </div>
                                    </li> 
                                        <div class="clear"> </div>
                                        <li>
                                        <textarea class="plain buffer" placeholder="Your text here"> Your text here</textarea>
                                        </li>
                                        <input class="send" type="submit" value="Send" />
                                        <!--
                                    <div class="send">
                                            <a href="#">SEND</a>
                                    </div>
                                    -->
                                </ul>
                        </form>
   
                    </div>
            </div>