<?php
if(!defined("INDEX")) die ("---");
$artikel = mysql_query("select * from halaman where id_halaman='$_GET[id]'");
$data=mysql_fetch_array($artikel);
$isi = $data['isi'];
?>
<center><div class="halaman">
<h2 class="judul"><?php echo $data['judul']; ?></h2>
<p>
<?php echo $isi; ?>
</p>
</div></center>