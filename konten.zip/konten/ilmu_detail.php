<?php
if(!defined("INDEX")) die ("---");

mysql_query("update ilmu set hits=hits+1
	where id_ilmu='$_GET[id]'");

$Informasi = mysql_query("select * from ilmu where id_ilmu='$_GET[id]'");
$data=mysql_fetch_array($Informasi);
$isi = $data['isi'];
?>

<div class="ilmu">
<h2 class="judul"><?php echo $data['judul']; ?></h2>
<p>
<?php if($data['gambar']!="") ?> <img src="gambar/opini/<?php echo $data['gambar']; ?>" class="gambar-ilmu" width="350">
<?php echo $isi; ?>
</p>
</div>