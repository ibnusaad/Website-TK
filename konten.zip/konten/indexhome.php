<?php
    if(!defined("INDEX")) die("---");   
?>
    <section id="meet-team">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title text-center wow fadeInDown">Tokoh HMI</h2>
                <p class="text-center wow fadeInDown">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>

            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <div class="team-member wow fadeInUp" data-wow-duration="400ms" data-wow-delay="0ms">
                        <div class="team-img">
                            <img class="img-responsive" src="images/team/01.jpg" alt="">
                        </div>
                        <div class="team-info">
                            <h3>Bin Burhan</h3>
                            <span>Co-Founder</span>
                        </div>
                        <p>Backed by some of the biggest names in the industry, Firefox OS is an open platform that fosters greater</p>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team-member wow fadeInUp" data-wow-duration="400ms" data-wow-delay="100ms">
                        <div class="team-img">
                            <img class="img-responsive" src="images/team/02.jpg" alt="">
                        </div>
                        <div class="team-info">
                            <h3>Jane Man</h3>
                            <span>Project Manager</span>
                        </div>
                        <p>Backed by some of the biggest names in the industry, Firefox OS is an open platform that fosters greater</p>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team-member wow fadeInUp" data-wow-duration="400ms" data-wow-delay="200ms">
                        <div class="team-img">
                            <img class="img-responsive" src="images/team/03.jpg" alt="">
                        </div>
                        <div class="team-info">
                            <h3>Pahlwan</h3>
                            <span>Designer</span>
                        </div>
                        <p>Backed by some of the biggest names in the industry, Firefox OS is an open platform that fosters greater</p>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team-member wow fadeInUp" data-wow-duration="400ms" data-wow-delay="300ms">
                        <div class="team-img">
                            <img class="img-responsive" src="images/team/04.jpg" alt="">
                        </div>
                        <div class="team-info">
                            <h3>Nasir uddin</h3>
                            <span>UI/UX</span>
                        </div>
                        <p>Backed by some of the biggest names in the industry, Firefox OS is an open platform that fosters greater</p>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="divider"></div>

           
               
   
    <section id="testimonial">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2">

                    <div id="carousel-testimonial" class="carousel slide text-center" data-ride="carousel">
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <p><img class="img-circle img-thumbnail" src="images/testimonial/01.jpg" alt=""></p>
                                <h4>Louise S. Morgan</h4>
                                <small>Treatment, storage, and disposal (TSD) worker</small>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut et dolore magna aliqua. Ut enim ad minim veniam</p>
                            </div>
                            <div class="item">
                                <p><img class="img-circle img-thumbnail" src="images/testimonial/01.jpg" alt=""></p>
                                <h4>Louise S. Morgan</h4>
                                <small>Treatment, storage, and disposal (TSD) worker</small>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut et dolore magna aliqua. Ut enim ad minim veniam</p>
                            </div>
                        </div>

                        <!-- Controls -->
                        <div class="btns">
                            <a class="btn btn-primary btn-sm" href="#carousel-testimonial" role="button" data-slide="prev">
                                <span class="fa fa-angle-left" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="btn btn-primary btn-sm" href="#carousel-testimonial" role="button" data-slide="next">
                                <span class="fa fa-angle-right" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/#testimonial-->

    <section id="blog">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title text-center wow fadeInDown">Opini Kader</h2>
            </div>
         
                     
    <?php
    if(!defined("INDEX")) die("---");
    
    $hal    = isset($_GET['hal']) ? $_GET['hal'] : 1;
    
    $batas  = 3;
    $posisi = ($hal-1) * $batas ;
    
    $ilmu = mysql_query("select * from ilmu order by id_ilmu desc limit $posisi, $batas");
    while($data = mysql_fetch_array($ilmu)){
        $isi = substr($data['isi'],0,500);
        $isi = substr($data['isi'],0,strrpos($isi," "));
?>
    <div class="ilmu">
        <h3 class="judul"><?php echo $data['judul']; ?></h3>
            <div class="col-md-4">
            <?php if($data['gambar']!="") ?> <img src="gambar/ilmu/<?php echo $data['gambar']; ?>" class="thumbnail" width="100%" height="250px">
       
            <div class="col-md-2">
                <?php echo $isi; ?> ... 
                <a href="?tampil=ilmu_detail&id=<?php echo $data['id_ilmu']; ?>" class="btn btn-success btn-xs">Selengkapnya</a><br><br><br><br><br>
            </div>
        </div>
    </div><br>
<?php
    }
    
    $semua = mysql_query("select * from ilmu");
    $jmldata = mysql_num_rows($semua);
    $jmlhal  = ceil($jmldata/$batas);   
    $sebelumnya = $hal - 1;
    $berikutnya = $hal + 1; 


    
    echo "<br><div class='paging'>" ;
    
    if($hal > 1){
        echo "<span class='btn btn-default'><a  href='?tampil=ilmu&hal=1'> Pertama</a></span> ";
        echo "<span class='btn btn-default'><a href='?tampil=ilmu&hal=$sebelumnya'> Sebelumnya</a></span> ";
    }else{
        echo "<span class='btn btn-success'> Pertama</span> ";
        echo "<span class='btn btn-success'> Sebelumnya</span> ";
    }
    
    for($i=1; $i<=$jmlhal; $i++){
        if($i == $hal) echo "<span class='btn btn-default'> <b>$i</b> </span> ";
        else echo "<span class='btn btn-default'><a href='?tampil=ilmu&hal=$i'> $i </a></span> ";
    }
    
    if($hal < $jmlhal){
        echo "<span class='btn btn-default'><a href='?tampil=ilmu&hal=$berikutnya'> Berikutnya </a></span> ";
        echo "<span class='btn btn-default'><a href='?tampil=ilmu&hal=$jmlhal'> Terakhir </a></span> ";
    }else{
        echo "<span class='btn btn-success'> Berikutnya </span> ";
        echo "<span class='btn btn-success'> Terakhir </span> ";        
    }
    
    echo "</div><br>";
     ?>
     </div>

                                   
              <br><br><br>             

    <section id="get-in-touch">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title text-center wow fadeInDown">Get in Touch</h2>
                <p class="text-center wow fadeInDown">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>
        </div>
    </section><!--/#get-in-touch-->

        <div id="google-map" style="height:650px" data-latitude="-0.5360785" data-longitude="117.1238037"></div>
    

    </div></section></div></section>