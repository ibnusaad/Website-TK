<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	
<h2 class="sub-header">Tambah Halaman</h2>

<form name="tambah" method="post" 
action="?tampil=halaman_tambahproses" enctype="multipart/form-data" class="form-horizontal">
<div class="form-group">
<label class="label-control col-md-2"> Judul Halaman </label>

<div class="col-md-4">
<input type="text" class="form-control" name="judul" size="50">
</div>
</div>

<div class="form-group">
<label class="label-control col-md-2"> Isi Halaman </label>
<div class="col-md-8">
<textarea class="ckeditor" name="isi" id="ckedtor"></textarea>
	</div>
	</div>

<div class="form-group">
<label class="label-control col-md-2"></label>
<div class="col-md-4">
<input type="submit" name="tambah" value="Tambah" class="btn btn-primary">
</div>
</div>
</form>