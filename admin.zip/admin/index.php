<html>
<head>
<title>Login Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="../css1/login.css">
</head>
<body>

<div id="container">
<h3 class="sub-header">Login Administrator</h3>
<form method="POST" action="ceklogin.php" class="form-horizontal">

<div class="form-group">
<label class="label-control col-md-4">Username</label>
<div class="col-md-8">
<input type="text" class="form-control" name="username" autofocus>
</div>
</div>

<div class="form-group">
<label class="label-control col-md-4">Password</label>
<div class="col-md-8">
<input type="password" class="form-control" name="password">
</div>
</div>

<div class="form-group">
<label class="label-control col-md-4"></label>
<div class="col-md-4">
<input type="submit" name="login" value="login" class="btn btn-primary btn-block">
</div>
</div>
</form>
</div>
</body>
</html>