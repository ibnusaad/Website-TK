<?php
mysql_query("delete from pesan where id_pesan='$_GET[id]'") or die (mysql_error());
echo "Data telah dihapus";
echo "<meta http-equiv='refresh'
content='1; url=?tampil=pesan'>";
?>