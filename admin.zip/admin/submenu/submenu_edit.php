<?php
	if(!defined("INDEX")) die("---");

	$sql = mysql_query("SELECT * FROM submenu WHERE id_submenu='$_GET[id]'") or die(mysql_error());
	$data  	= mysql_fetch_array($sql);
?>

<h2>Edit Sub Menu</h2>

<form name="edit" method="post" action="?tampil=submenu_editproses" class="form-horizontal">
<input type="hidden" name="id" value="<?php echo $data['id_submenu']; ?>">

		<div class="form-group">
<label class="label-control col-md-2">Judul Subenu</label>
<div class="col-md-4">
<input type="text" name="judul" class="form-control"  value="<?php echo $data['judul']; ?>">
</div>
</div> 
		
		
		<div class="form-group">
<label class="label-control col-md-2">Induk</label>
<div class="col-md-4">
			<select name="induk" class="form-control">
			<?php
				$sqlmenu = mysql_query("select * from menu");
				while($datamenu = mysql_fetch_array($sqlmenu)){
					if($datamenu['id_menu'] == $data['id_menu']) echo"<option value='$datamenu[id_menu]' selected> $datamenu[judul] </option>";
					else  echo"<option value='$datamenu[id_menu]'> $datamenu[judul] </option>";
				}
			?>
			</select>
		</div>
		</div>

		<div class="form-group">
<label class="label-control col-md-2">Link</label>
<div class="col-md-4">			
<input type="text" name="link" class="form-control" value="<?php echo $data['link']; ?>">
	</div>
	</div>

	<div class="form-group">
<label class="label-control col-md-2">Urutan</label>
<div class="col-md-4">	
<input type="text" name="urutan" class="form-control" value="<?php echo $data['urutan']; ?>">
</div>
</div>

<div class="form-group">
			<div class="col-md-2 col-md-offset-2">
<input type="submit" name="edit" value="Edit" class="btn btn-primary">
</div></div>
</form>